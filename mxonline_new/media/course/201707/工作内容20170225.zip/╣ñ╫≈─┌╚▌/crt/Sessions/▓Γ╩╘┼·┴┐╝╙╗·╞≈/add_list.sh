
s1='Android-S01-120.92.33.216.ini'


serverId=2
for i in `cat test_ip_list`
do
	echo $i
	echo $serverId
	echo Android-S$serverId-$i.ini
	if [ $serverId -lt 10 ]
	    then
		cp $s1 Android-S0$serverId-$i.ini
	else
		cp $s1 Android-S$serverId-$i.ini		
	fi


	((j++))

done


